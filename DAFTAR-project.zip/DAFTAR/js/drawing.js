/* Pointer Events drawing engine: supports finger, mouse and stylus. */
const Drawing = (() => {
 let canvas,ctx,tool='pen',color='#172b4d',width=3,drawing=false,current=null,undo=[],redo=[],pageKey='';
 const snapshots=()=>{try{return ctx.getImageData(0,0,canvas.width,canvas.height)}catch(e){return null}};
 function init(el){canvas=el;ctx=canvas.getContext('2d',{willReadFrequently:true});resize();canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);['pointerup','pointercancel','pointerleave'].forEach(n=>canvas.addEventListener(n,up));}
 function resize(){if(!canvas)return;const old=document.createElement('canvas');old.width=canvas.width;old.height=canvas.height;if(ctx&&canvas.width)old.getContext('2d').drawImage(canvas,0,0);const r=canvas.getBoundingClientRect(),dpr=Math.min(window.devicePixelRatio||1,2);canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.scale(dpr,dpr);if(old.width)ctx.drawImage(old,0,0,old.width,old.height,0,0,r.width,r.height);}
 function point(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top,p:e.pressure||.5}}
 function down(e){if(tool==='select')return;e.preventDefault();canvas.setPointerCapture?.(e.pointerId);drawing=true;current={points:[point(e)],tool,color,width};undo.push(snapshots());if(undo.length>35)undo.shift();redo=[];ctx.beginPath();const p=current.points[0];ctx.moveTo(p.x,p.y);ctx.lineCap='round';ctx.lineJoin='round';style();ctx.lineTo(p.x+.1,p.y+.1);ctx.stroke();}
 function style(){ctx.globalCompositeOperation=tool==='eraser'?'destination-out':'source-over';ctx.strokeStyle=color;ctx.lineWidth=tool==='eraser'?Math.max(width*4,16):tool==='highlighter'?width*4:width;ctx.globalAlpha=tool==='highlighter'?.25:1}
 function move(e){if(!drawing)return;e.preventDefault();const p=point(e);current.points.push(p);style();ctx.lineTo(p.x,p.y);ctx.stroke();}
 function up(){if(!drawing)return;drawing=false;ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
 function setTool(v){tool=v}function setColor(v){color=v}function setWidth(v){width=Number(v)}
 function clear(){undo.push(snapshots());redo=[];ctx.clearRect(0,0,canvas.width,canvas.height)}
 function undoStep(){if(!undo.length)return;redo.push(snapshots());const im=undo.pop();ctx.clearRect(0,0,canvas.width,canvas.height);if(im)ctx.putImageData(im,0,0)}
 function redoStep(){if(!redo.length)return;undo.push(snapshots());const im=redo.pop();ctx.clearRect(0,0,canvas.width,canvas.height);if(im)ctx.putImageData(im,0,0)}
 function exportData(){return canvas.toDataURL('image/png')}
 function loadData(data){clear();if(!data)return;const img=new Image();img.onload=()=>ctx.drawImage(img,0,0,canvas.width,canvas.height);img.src=data}
 function resetHistory(){undo=[];redo=[]}
 return {init,resize,setTool,setColor,setWidth,clear,undoStep,redoStep,exportData,loadData,resetHistory};
})();